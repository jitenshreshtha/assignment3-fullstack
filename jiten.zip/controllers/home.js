module.exports.homeController = async(req,res)=>{
    res.render('pages/index');
}