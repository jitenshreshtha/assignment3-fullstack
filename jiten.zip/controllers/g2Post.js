const User = require('../models/user');
const bcrypt= require('bcrypt');

module.exports.g2Post = async(req,res)=>{
    try{
        const {firstname,lastname,license,age,dob,cardetails} = req.body;

        const encryptedLicense = await bcrypt.hash(license,10);
        await User.findByIdAndUpdate(req.session.user_id, {
          firstname,
          lastname,
          license: encryptedLicense,
          age,
          dob,
          cardetails
      });
        res.redirect(`/g`);
    }
    catch(err){
        console.log("error in g2post :" ,err);
    }
}