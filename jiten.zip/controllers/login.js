module.exports.loginController = async(req,res) =>{
    res.render('pages/login');
}