const User = require('../models/user.js');
module.exports.g2Controller = async(req,res) =>{
    try {
        const user = await User.findById(req.session.user_id);
        res.render('pages/g2', { user });
    } catch (error) {
        console.error('Error fetching user data:', error);
        res.render('pages/g2', { user: null });
    }
}